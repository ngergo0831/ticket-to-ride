Teendők:

-   [ ] Várakozó mutassa a csatlakozott játékosok nevét
-   [ ] Várakozó mutassa hány játékos kell még az indításhoz
-   [ ] Várakozót aki készítette legyen egy kezdés gombja
-   [ ] Új térkép letöltése teamsből
