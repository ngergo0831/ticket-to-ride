import React from "react";

function NotFound() {
    return (
        <div className="game-notFound">
            <div>404 lol</div>
        </div>
    );
}

export default NotFound;
