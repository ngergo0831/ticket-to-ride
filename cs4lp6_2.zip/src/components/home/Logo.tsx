import React from "react";
import logo from "../../res/logo.png";

function Logo() {
    return <img src={logo} alt={"logo"} className="logo"/>;
}

export default Logo;
