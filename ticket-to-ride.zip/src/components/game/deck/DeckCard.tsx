import { rotatedImages } from "../../../Images";

function DeckCard() {
    return (
        <div className="deck-card">
            <img src={rotatedImages["red_r"]} alt="shuuu" />
        </div>
    );
}

export default DeckCard;
