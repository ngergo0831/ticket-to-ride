import React from "react";

function DeckTicket() {
    return <div className="deck-ticket">Destination pakli</div>;
}

export default DeckTicket;
