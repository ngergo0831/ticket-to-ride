import React from "react";

function DeckTrain() {
    return <div className="deck-train">Vasútikocsi pakli</div>;
}

export default DeckTrain;
