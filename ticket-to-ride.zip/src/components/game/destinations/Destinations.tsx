import React from "react";

import "./destinations.css";

function Destinations() {
    return (
        <div className="game-destinations">
            <div>Current destinations</div>
            <div>Roma - Praga</div>
            <div>Moscow - Berlin</div>
        </div>
    );
}

export default Destinations;
